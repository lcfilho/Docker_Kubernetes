#!/bin/bash

mkdir -p /home/luis.filho/{bin,crawler_ibov/{processados,indexados},crawler_nasdaq/{processados,indexados},crawler_dolar/processados}

